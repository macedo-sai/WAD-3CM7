SRC: Contiene el código fuente de los servlets y estructura de la webapp sobre la cual se trabajó durante la práctica.

SRC--
	Main--resources: Contiene los recursos usados para ejecutar los servlets en este caso vacía.
		--webapp--WEB-INF--web.xml --Contenedor de la estructura de nuestra página web
		--index.jsp--Página princilal tipo Java Server Page

	Puntos--Punto 1 : Empaquetado(carpeta) con los 4 servlets desarrollados durante la practica
		  --Punto 2
		  --Punto 3
		  --Punto 4

Compilamos mediante nuestra herramienta eclipse  ya configurada con  Jetty para dar soporte interno a Tomcat.

